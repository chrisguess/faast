# Sample app demonstrating CI/CD flow

This application demonstrates a CI/CD workflow against Dash Enterprise for a Dash application using Github Actions.

To use this continuous deployment, copy the `.github/` directory to your project and set the following environment variables.

### Required environment variables

1. `APP_NAME`: The name of the app to be deployed to Dash Enterprise
2. `DASH_ENTERPRISE_API_KEY`: The API key for the DE instance you are deploying to. Required for `dds-client`.
3. `DASH_ENTERPRISE_URL`: The URL of the DE instance you are deploying to, without the `https://` prefix. For example: `dash-services.plotly.host`
4. `DASH_ENTERPRISE_USERNAME`: The username for the associated API key. Required for `dds-client`.
5. `DASH_SSH_KEY`: A private key configured for the associated user. See https://dash.plotly.com/dash-enterprise/ssh. Once configured this would usually be set by copying using `pbcopy < ~/.ssh/id_rsa` and pasting the result as this entry.

## On pull request

1. Run `flake8`, `black`, and `pytest`
2. If tests succeed, deploy to `$DASH_ENTERPRISE_URL:$APP_NAME-$EVENT-NUMBER`
   - If an app does not exist under this URL, the pipeline will create one. Otherwise it will deploy to the existing app.
3. If deploy succeeds, comment on the PR with a deploy link and commit SHA reflecting the full diffs after that deploy.

## On push to `main`

1. Deploy to `$DASH_ENTERPRISE_URL:$APP_NAME`
   - If an app does not exist under this URL, the deploy will fail. This application must be created manually.
2. That's it! The tests are not run.
